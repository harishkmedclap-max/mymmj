import Header from "./components/header/header";
import Hero from "./components/landing/hero";
import Trust from "./components/landing/trust";

export default function Home() {
  return (
    <>
      <Header />
      <Hero />
      <Trust />
    </>
  );
}